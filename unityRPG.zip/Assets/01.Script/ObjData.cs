using UnityEngine;

public class ObjData : MonoBehaviour
{
    public int id;
    public bool isNpc;
}
